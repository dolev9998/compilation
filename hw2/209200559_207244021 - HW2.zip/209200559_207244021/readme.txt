אורי עדיקה - 209200559	Ori Adika
דולב דוד	  - 207244021	Dolev David